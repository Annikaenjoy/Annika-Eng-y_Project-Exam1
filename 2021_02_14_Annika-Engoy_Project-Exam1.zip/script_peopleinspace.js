
const secondUrl = "http://api.open-notify.org/astros.json";
const resultsContainer2 = document.querySelector(".results2");

async function fetchNumber() {
    try {
        const response = await fetch(secondUrl);


        const result = await response.json();
        console.dir(result);


        resultsContainer2.innerHTML = "";


        const numberOfPeople = result;
        console.log(numberOfPeople);

        resultsContainer2.innerHTML += `<div class="results2">
        <h2>How many people are there in space right now?</h2>
        <a href="astronauts.html"<p>There are ${numberOfPeople.number} people in space right now! </p></a>
        </div>`;

    } catch (error) {
        console.dir("An error occurred");
        resultsContainer.innerHTML = displayError("An error occurred when calling the API");
    }
    finally {
        console.dir("finally");
    }
}
fetchNumber();