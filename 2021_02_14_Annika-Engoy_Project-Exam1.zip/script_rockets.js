const url = "https://api.spacexdata.com/v4/rockets";

const resultsContainer = document.querySelector(".results");

async function fetchInfo() {
    try {
        const response = await fetch(url);

        const result = await response.json();
        console.dir(result);

        const rocketInfo = result;
        resultsContainer.innerHTML = "";

        for (let i = 0; i < rocketInfo.length; i++) {
            console.dir(rocketInfo[i].name);

            if (i === 10) {
                break;
            }

            resultsContainer.innerHTML += ` <div class="space-results">
            <section class="space-col">
            <a href="${rocketInfo[i].wikipedia}">
            <h2 class="launchRocket-h2">${rocketInfo[i].name}</h2>
            <p class="success-rate">Success rate: </p>
            <p class="percent"> ${rocketInfo[i].success_rate_pct}%</p>
            <p>First flight: ${rocketInfo[i].first_flight} </p> 
            <p>Cost per launch: $ ${rocketInfo[i].cost_per_launch} </p>
            <p>Height: ${rocketInfo[i].height.meters} meters </p>
            <p>Diameter: ${rocketInfo[i].diameter.meters} meters </p>
            <p>Mass: ${rocketInfo[i].diameter.meters} kg </p>
            <button class="info-button">View More</button>
            </a></section>
            </div>`;
        }
    } catch (error) {
        console.dir("An error occurred");
        resultsContainer.innerHTML = displayError("An error occurred when calling the API");
    }
    finally {
        console.dir("finally");
    }
}
fetchInfo();