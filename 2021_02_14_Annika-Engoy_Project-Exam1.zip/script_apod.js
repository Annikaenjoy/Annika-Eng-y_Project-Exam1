
const url = "https://api.nasa.gov/planetary/apod?api_key=UmCFQCI897mZahyw2aBjmJQQIm8eVgF77fU3I9vn";
const resultsContainer = document.querySelector(".apod-results");

async function fetchProducts() {
    try {
        const response = await fetch(url);


        const result = await response.json();
        console.dir(result);

        resultsContainer.innerHTML = "";


        const apodInfo = result;
        console.log(apodInfo);
        resultsContainer.innerHTML += `<div class="apod-results">
        <img class="apod-img" src="${apodInfo.hdurl}" alt="Astronomy Picture of the Day" title="Astronomy Picture of the Day">
        <section class="col1">
        <div class="heading-container">
        <h1 class="apod-h1">Astronomy Picture of the Day</h1>
        <h2>${apodInfo.title}</h2>
        </div>
        </section>
        <section class="col2">
        <p><b>Date: </b>${apodInfo.date}</p>
        <p><b>Description: </b>${apodInfo.explanation}</p>
        </section>
        </div>`;

    } catch (error) {
        console.dir("An error occurred");
        resultsContainer.innerHTML = displayError("An error occurred when calling the API");
    }
    finally {
        console.dir("finally");
    }
}
fetchProducts();