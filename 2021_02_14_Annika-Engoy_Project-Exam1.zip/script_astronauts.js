
const url = "http://api.open-notify.org/astros.json";

const resultsContainer = document.querySelector(".results");

async function fetchInfo() {
    try {
        const response = await fetch(url);

        const result = await response.json();
        console.dir(result);

        const astronautInfo = result;
        resultsContainer.innerHTML = "";

        for (let i = 0; i < astronautInfo.people.length; i++) {
            console.dir(astronautInfo.people[i].name);
            console.dir()

            resultsContainer.innerHTML += ` <div class="space-results">
            <section class="space-col">
            <h2>${astronautInfo.people[i].name}</h2>
            <p> Craft: ${astronautInfo.people[i].craft}</p>
            </section>
            </div>`;
        }
    } catch (error) {
        console.dir("An error occurred");
        resultsContainer.innerHTML = displayError("An error occurred when calling the API");
    }
    finally {
        console.dir("finally");
    }
}

fetchInfo();
