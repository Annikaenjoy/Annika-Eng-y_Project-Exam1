const form = document.querySelector(".form-container")
const name = document.querySelector("#name");
const nameError = document.querySelector("#nameError");
const lastName = document.querySelector("#lastName");
const lastNameError = document.querySelector("#lastNameError");
const email = document.querySelector("#email");
const emailError = document.querySelector("#emailError");
const message = document.querySelector("#message");
const button = document.querySelector("button");

function checkIfValidForm() {
    if (checkLength(name.value, 1) && (checkLength(lastName.value, 1) && validateEmail(email.value))) {
        message.innerHTML = `Your message has successfully been sendt!`
    } else {
        message.innerHTML = `ERROR! Your form has not been filled in properly`;
    }
}

button.addEventListener("click", checkIfValidForm);

function validateForm(event) {
    event.preventDefault();

    if (checkLength(name.value, 0) === true) {
        nameError.style.display = "none";
    }
    else {
        nameError.style.display = "block";
    }
    if (checkLength(lastName.value, 0) === true) {
        lastNameError.style.display = "none";
    }
    else {
        lastNameError.style.display = "block";
    }
    if (validateEmail(email.value) === true) {
        emailError.style.display = "none";
    }
    else {
        emailError.style.display = "block";
    }
    console.dir("Check");

}

form.addEventListener("submit", validateForm);

function checkLength(value, len) {
    if (value.trim().length > len) {
        return true;
    }
    else {
        return false;
    }
}

function validateEmail(email) {
    const regEX = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    const patternMatches = regEX.test(email);
    return patternMatches;
}

