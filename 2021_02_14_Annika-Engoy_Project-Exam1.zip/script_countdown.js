const url = "https://api.spacexdata.com/v4/launches/upcoming";

async function fetchCountdown() {
    try {
        const response = await fetch(url);


        const result = await response.json();
        console.dir(result);


        const countdownInfo = result;
        console.log(countdownInfo);
        let date = new Date(countdownInfo[0].date_unix * 1000);
        //console.log(date)

        // countdown from https://www.educative.io/edpresso/how-to-create-a-countdown-timer-using-javascript

        var timeFunc = setInterval(function async() {
            var now = new Date().getTime();
            console.log(now)
            console.log(date)
            var timeleft = date - now;

            var days = Math.floor(timeleft / (1000 * 60 * 60 * 24));
            var hours = Math.floor((timeleft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            var minutes = Math.floor((timeleft % (1000 * 60 * 60)) / (1000 * 60));
            var seconds = Math.floor((timeleft % (1000 * 60)) / 1000);

            document.getElementById("days").innerHTML = days + "d"
            document.getElementById("hours").innerHTML = hours + "h"
            document.getElementById("mins").innerHTML = minutes + "m"
            document.getElementById("secs").innerHTML = seconds + "s"

            if (timeleft < 0) {
                clearInterval(timeFunc);
                document.getElementById("days").innerHTML = ""
                document.getElementById("hours").innerHTML = ""
                document.getElementById("mins").innerHTML = ""
                document.getElementById("secs").innerHTML = ""
                document.getElementById("end").innerHTML = "EXPIRED";
            }
        }, 1000)

    } catch (error) {
        console.error(error);
    }
    finally {
        console.dir("finally");
    }
}
fetchCountdown()








