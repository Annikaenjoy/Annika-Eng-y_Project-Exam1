const url = "https://api.spacexdata.com/v2/launches/all";

const resultsContainer = document.querySelector(".results");

async function fetchInfo() {
    try {
        const response = await fetch(url);

        const result = await response.json();
        console.dir(result);

        const launchInfo = result;
        resultsContainer.innerHTML = "";

        for (let i = 0; i < launchInfo.length; i++) {
            console.dir(launchInfo[i].name);

            if (i === 30) {
                break;
            }

            const launchDate = new Date(launchInfo.launch_date_unix * 1000);
            const date = new Date(launchDate * 1000);
            const hours = date.getHours();
            const minutes = "0" + date.getMinutes();
            const seconds = "0" + date.getSeconds();

            var formattedTime = hours + ':' + minutes.substr(-2) + ':' + seconds.substr(-2);
            console.log(formattedTime);

            resultsContainer.innerHTML += ` <div class="space-results">
            <section class="space-col">
            <a href="${launchInfo[i].links.video_link}">
            <h2 class="launchRocket-h2">${launchInfo[i].mission_name}</h2>
            <img class="patch-small" src="${launchInfo[i].links.mission_patch_small}">
            <p>Rocket name: ${launchInfo[i].rocket.rocket_name}</p>
            <p>Flight number: ${launchInfo[i].flight_number}</p>
            <p>Launch year: ${launchInfo[i].launch_year}</p>
            <p>Launch date: ${launchInfo[i].launchDate}</p>
            <p>Rocket type: ${launchInfo[i].rocket.rocket_type}</p>
            <p>Launch site: ${launchInfo[i].launch_site.site_name}</p>
            <p>Launch success: ${launchInfo[i].launch_success ? `<i class="fas fa-check-circle"></i>
` : ` <i class="fas fa-times"></i>`}</p>
            <button class="info-button">View More</button>
            </a></section> 
            </div>`;
        }


    } catch (error) {
        console.dir("An error occurred");
        resultsContainer.innerHTML = displayError("An error occurred when calling the API");
    }
    finally {
        console.dir("finally");
    }
}
fetchInfo();