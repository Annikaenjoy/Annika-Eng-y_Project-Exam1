const thirdUrl = "http://api.open-notify.org/iss-now.json";

const resultsContainer3 = document.querySelector(".results3");

async function fetchIssInfo() {
    try {
        const response = await fetch(thirdUrl);


        const result = await response.json();
        console.dir(result);

        resultsContainer3.innerHTML = "";

        const issInfo = result;
        console.log(issInfo);

        const currentDate = new Date(issInfo.timestamp * 1000);
        const date = new Date(currentDate * 1000);
        const hours = date.getHours();
        const minutes = "0" + date.getMinutes();
        const seconds = "0" + date.getSeconds();

        var formattedTime = hours + ':' + minutes.substr(-2) + ':' + seconds.substr(-2);
        console.log(formattedTime);

        resultsContainer3.innerHTML += `<div class="results3">
        <a href="https://www.nasa.gov/mission_pages/station/main/index.html">
        <h2>The International Space Station</h2>
        <h3>Current Location:</h3>
        <p>Timestamp: ${currentDate}</p>
        <p>Latitude: ${issInfo.iss_position.latitude}</p>
        <p>Longitude: ${issInfo.iss_position.longitude}</p>
        <button class="info-button">View More</button>
        </a>
        </div>`



    } catch (error) {
        console.dir("An error occurred");
        resultsContainer3.innerHTML = displayError("An error occurred when calling the API");
    }
    finally {
        console.dir("finally");
    }
}
fetchIssInfo();

